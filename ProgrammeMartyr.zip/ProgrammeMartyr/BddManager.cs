﻿using MySql.Data.MySqlClient;
using Mysqlx.Connection;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ZstdSharp.Unsafe;

namespace ProgrammeMartyr
{
    internal class BddManager
    {
        ///<summary>
        ///Déterminer la base de donnée accessible par le programme 
        ///</summary>
        ///<parametres>
        ///connexion : objet de connexion à la base de donnée MySQL
        ///</parametres>
        public string ConnexionBdd()
        {
            bool BddFound = false;
            string connexionString = "";

            try
            {
                //connexionString = "server=10.10.51.98;database=solune;port=3306;UserId=solune;password=root";
                connexionString = "server=192.168.129.3;database=solune;port=3306;UserId=PC_Ecole;password=root";
                //connexionString = "server=localhost;database=astronautic;port=3306;UserId=root;password=root";

                MySqlConnection testConnexion = new MySqlConnection(connexionString);
                testConnexion.Open();
                testConnexion.Close();
                BddFound = true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                throw;
            }

            if (connexionString == "")
            {
                Application.Current.Shutdown();
                throw new Exception("Aucune base de donnée accessible. Veuillez vérifier votre connexion internet ou contacter l'administrateur du programme.");
            }

            return connexionString;
        }

        /// <summary>
        /// Retrieves all character records from the database.
        /// </summary>
        /// <remarks>The method establishes a new database connection for each call and retrieves all rows
        /// from the "personnage" table. The caller is responsible for handling any exceptions that may be thrown if the
        /// database connection fails or if an error occurs during data retrieval.</remarks>
        /// <returns>A <see cref="DataSet"/> containing the data for all characters. The DataSet will include a table named
        /// "personnage" with the retrieved records. The DataSet will be empty if no records are found.</returns>
        public DataSet DownloadCharacters()
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = "SELECT * FROM personnage";
            DataSet Persos = new DataSet();

            try
            {
                connexion.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, connexion);
                da.Fill(Persos, "personnage");
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
            return Persos;
        }

        public bool UserExist(string mail)
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = $"SELECT * FROM user WHERE UserMail = '{mail}'";
            DataSet userData = new DataSet();
            try
            {
                connexion.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, connexion);
                da.Fill(userData, "user");
                connexion.Close();
                return userData.Tables[0].Rows.Count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Générer un iventaire pour le novel utilisateur en lui attribuant les items de départ
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="perso"></param>
        public void CreateInventaire(int userId, Personnage perso)
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = $"INSERT INTO useritem (UserItemMoney, UserItemCrystal, UserItemUpgradeAbility, UserItemPersonnagesId) VALUES (0, 0, 0, {perso.Id})";
            try
            {
                connexion.Open();
                MySqlCommand cmd = new MySqlCommand(query, connexion);
                cmd.ExecuteNonQuery();
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
            int lastInsertedId;
            query = $"SELECT LAST_INSERT_ID()";
            try
            {
                connexion.Open();
                MySqlCommand cmd = new MySqlCommand(query, connexion);
                lastInsertedId = Convert.ToInt32(cmd.ExecuteScalar());
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }

            query = $"UPDATE user SET UserUserItemId = {lastInsertedId} WHERE UserId = {userId}";
            try
            {
                connexion.Open();
                MySqlCommand cmd = new MySqlCommand(query, connexion);
                cmd.ExecuteNonQuery();
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Retrieves the inventory data for the specified user from the database.
        /// </summary>
        /// <param name="userID">The unique identifier of the user whose inventory is to be downloaded. Must correspond to a valid user in
        /// the database.</param>
        /// <returns>A DataSet containing the inventory items for the specified user. The DataSet will contain a table named
        /// "inventaire". If the user has no items, the table will be empty.</returns>
        public DataSet DownloadInventaire(int userID)
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = $"select * from useritem where UserItemId like (select UserItemId from user where userId = {userID})";
            DataSet Inventaire = new DataSet();
            try
            {
                connexion.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, connexion);
                da.Fill(Inventaire, "inventaire");
                connexion.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
            return Inventaire;
        }

        public bool CreateUser(string mail, string password, string username, ListeGenerale Glist, out Utilisateur user)
        {
            bool successfullAction;
            user = null;

            //Ajout d'un nouvel utilisateur dans la base de donnée
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = $"INSERT INTO user (UserMail, UserPassword, UserName) VALUES ('{mail}', '{password}', '{username}')";
            try
            {
                connexion.Open();
                MySqlCommand cmd = new MySqlCommand(query, connexion);
                cmd.ExecuteNonQuery();
                connexion.Close();
                successfullAction = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }


            //récupération de l'utilisateur nouvellement créé
            if (successfullAction)
            {
                if (ConnectUser(mail, password, Glist, out DataSet userData))
                {
                    CreateInventaire(int.Parse(userData.Tables[0].Rows[0]["UserId"].ToString()), Glist.ListePerso[0]);

                }

                assignUser(userData, Glist, out user);

            }
            return successfullAction;
        }

        public bool ConnectUser(string mail, string password, ListeGenerale Glist, out DataSet userData)
        {

            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = $"SELECT * FROM user WHERE UserMail = '{mail}' AND UserPassword = '{password}'";
            userData = new DataSet();
            try
            {
                connexion.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, connexion);
                da.Fill(userData, "user");
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }

            if (userData.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                MessageBox.Show("Identifiants incorrects. Veuillez réessayer.");
                return false;
            }
        }

        public void assignUser(DataSet userData, ListeGenerale Glist, out Utilisateur user)
        {
            user = new Utilisateur(userData.Tables[0].Rows[0]["UserName"].ToString(), userData.Tables[0].Rows[0]["UserMail"].ToString(), userData.Tables[0].Rows[0]["UserPassword"].ToString(), int.Parse(userData.Tables[0].Rows[0]["UserId"].ToString()), Glist);
        }

        public DataSet DownloadModifiers()
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = "SELECT * FROM modifyer";
            DataSet Modifiers = new DataSet();
            try
            {
                connexion.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, connexion);
                da.Fill(Modifiers, "modifyer");
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
            return Modifiers;
        }

        public DataSet DownloadAttacks()
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = "SELECT * FROM attaque";
            DataSet Attacks = new DataSet();
            try
            {
                connexion.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, connexion);
                da.Fill(Attacks, "attaque");
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
            return Attacks;
        }

        public DataSet DownloadPossede()
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = "SELECT * FROM possede";
            DataSet Possede = new DataSet();
            try
            {
                connexion.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, connexion);
                da.Fill(Possede, "possede");
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }

            return Possede;
        }

        public void UpdateInventaire(int userId, int money, int crystal, int upgrade)
        {
            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = $"UPDATE useritem SET UserItemMoney = {money}, UserItemCrystal = {crystal}, UserItemUpgradeAbility = {upgrade} WHERE UserItemId = (select UserUserItemId from user where UserId = {userId})";
            try
            {
                connexion.Open();
                MySqlCommand cmd = new MySqlCommand(query, connexion);
                cmd.ExecuteNonQuery();
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        public void AddPersoToUser(Utilisateur user, List<Personnage> listePersos)
        {
            string persosIds = null;
            foreach(Personnage perso in listePersos)
            {
                if (persosIds == null)
                {
                    persosIds = $"{perso.Id}";
                }
                else
                {
                    persosIds += $", {perso.Id}";
                }
            }


            MySqlConnection connexion = new MySqlConnection(ConnexionBdd());
            string query = $"UPDATE userItem useritem SET UserItemPersonnagesId = '{persosIds}' WHERE UserItemId = (select UserUserItemId from user where UserId = {user.Id})";
            try
            {
                connexion.Open();
                MySqlCommand cmd = new MySqlCommand(query, connexion);
                cmd.ExecuteNonQuery();
                connexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }
    }
}
